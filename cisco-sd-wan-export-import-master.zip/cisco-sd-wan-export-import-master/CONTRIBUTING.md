# Cisco Sample Code

This project, and the code contained herein, is provided for example or demonstration purposes by Cisco for use by our partners and customers in working with Cisco's products and services.  While Cisco's customers and partners are free to use this code according to the terms of the [LICENSE](./LICENSE) associated with this project, this is not an *Open Source* project in as much as we are not seeking to build a community around the project and its capabilities.

We do desire to provide functional and high-quality examples and demonstrations.  If you should discover some bug, issue, or opportunity for enhancement with the sample code contained in this project, please notify us by creating a new **Issue**.
